#ifndef CAN_H
#define CAN_H

#include <global.h>
#include <Canbus.h>
#include <mcp2515_defs.h>
#include <mcp2515.h>
#include <defaults.h>
#include <Arduino.h>

static volatile signed int brake_pressure_rear;
static volatile signed int brake_pressure_front;
static volatile signed int brake_temp_fl;
static volatile signed int brake_temp_fr;
static volatile signed int brake_temp_rl;
static volatile signed int brake_temp_rr;
static volatile unsigned int fl_wheel_speed;
static volatile unsigned int fr_wheel_speed;
static volatile unsigned int rl_wheel_speed;
static volatile unsigned int rr_wheel_speed;
static volatile unsigned int engine_rpm;
static volatile unsigned int manifold_air_pressure;
static volatile signed int manifold_air_temp;
static volatile unsigned int throttle_posn;
static volatile unsigned int engine_oil_temp;
static volatile unsigned int oil_pressure;
static volatile unsigned int coolant_temp;
static volatile unsigned int neut_gear;
static volatile signed int gear;

static volatile unsigned int byte0, byte1, byte2, byte3, byte4, byte5, byte6, byte7, nibble13;



int can_setup();
unsigned int can_read(unsigned int adr);

#endif
