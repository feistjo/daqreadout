#include <global.h>
#include <Canbus.h>
#include <mcp2515_defs.h>
#include <mcp2515.h>
#include <defaults.h>
#include <can.h>
#include <Arduino.h>

int can_setup(){

  //Initialise MCP2515 CAN controller at the specified speed
//  if(mcp2515_init(0))
//  {
//    return 0;
//  }
//  return 1;
  return !mcp2515_init(0);
}

unsigned int can_read(unsigned int addr) {
  // Serial.begin(9600);

  //Initialise MCP2515 CAN controller at the specified speed
  // if(mcp2515_init(0))
 //    Serial.println("CAN Init ok");
 //  else
 //    Serial.println("Can't Init CAN");

  // delay(1000);
  
  while(1) {
    // Read Message
    tCAN r_message;
    if (mcp2515_check_message()) 
    {
      if (mcp2515_get_message(&r_message)) 
      {
        //Serial.print("ID: ");
        //Serial.println(r_message.id,HEX);
        switch(r_message.id) 
        { 
          case 0x65D: // brake temp front left, front right, rear left, rear right
            // brake temp front left
            byte0 = r_message.data[0];
            byte0 = byte0 << 8;
            byte1 = r_message.data[1];
            brake_temp_fl = byte0 + byte1;
            if (addr == 2) {
              return brake_temp_fl;
            }

            // brake temp front right
            byte2 = r_message.data[2];
            byte2 = byte2 << 8;
            byte3 = r_message.data[3];
            brake_temp_fr = byte2 + byte3;
            if (addr == 3) {
              return brake_temp_fr;
            }

            // brake temp rear left
            byte4 = r_message.data[4];
            byte4 = byte4 << 8;
            byte5 = r_message.data[5];
            brake_temp_rl = byte4 + byte5;
            if (addr == 4) {
              return brake_temp_rl;
            }

            // brake temp rear right
            byte6 = r_message.data[6];
            byte6 = byte6 << 8;
            byte7 = r_message.data[7];
            brake_temp_rr = byte6 + byte7;
            if (addr == 4) {
              return brake_temp_rr;
            }

          case 0x655: // brake pressure front, brake pressure rear, coolant pressure, power steering pressure
            // brake pressure rear: second and third bytes
            byte2 = r_message.data[2];
            byte2 = byte2 << 8; //shift by 8 bits
            byte3 = r_message.data[3];
            brake_pressure_rear = byte2 + byte3;
            //Serial.print("Brake Pressure Rear: ");
            //Serial.println(brake_pressure_rear);
            if (addr == 00){
              return brake_pressure_rear;
            }
            // brake pressure front:  zeroeth and first bytes
            byte0 = r_message.data[0];
            byte0 = byte0 << 8;
            byte1 = r_message.data[1];
            brake_pressure_front = byte0 + byte1;
            if (addr == 01) {
              return brake_pressure_front;
            }
            //Serial.print("Brake Pressure Front: ");
            //Serial.println(brake_pressure_front);
          case 0x648: // wheel speed front left, front right, back left, back right
            // wheel speed front left
            byte0 = r_message.data[0];
            byte0 = byte0 << 8;
            byte1 = r_message.data[1];
            fl_wheel_speed = byte0 + byte1;
            if (addr == 10) {
              return fl_wheel_speed;
            }
            //Serial.print("wheel speed front left: ");
            //Serial.println(fl_wheel_speed);
            
            // wheel speed front right
            byte2 = r_message.data[2];
            byte2 = byte2 << 8;
            byte3 = r_message.data[3];
            fr_wheel_speed = byte2 + byte3;
            if (addr == 11) {
              return fr_wheel_speed;
            }
            //Serial.print("wheel speed front right: ");
            //Serial.println(fr_wheel_speed);
            
            // wheel speed rear left
            byte4 = r_message.data[4];
            byte4 = byte4 << 8;
            byte5 = r_message.data[5];
            rl_wheel_speed = byte4 + byte5;
            if (addr == 12) {
              return rl_wheel_speed;
            }
            //Serial.print("wheel speed rear left: ");
            //Serial.println(rl_wheel_speed);
  
            // wheel speed rear right
            byte6 = r_message.data[6];
            byte6 = byte6 << 8;
            byte7 = r_message.data[7];
            rr_wheel_speed = byte6 + byte7;
            if (addr == 13) {
              return rr_wheel_speed;
            }
            //Serial.print("wheel speed rear right: ");
            //Serial.println(rr_wheel_speed);
            
          case 0x640: // engine speed, throttle position, manifold air pressure, manifold air temperature
            // engine speed
            byte0 = r_message.data[0];
            byte0 = byte0 << 8;
            byte1 = r_message.data[1];
            engine_rpm = byte0 + byte1;
            //Serial.print("engine speed: ");
            //Serial.println(engine_rpm);
            if(addr == 50){
              return engine_rpm;
            }
            
            // manifold air pressure
            byte2 = r_message.data[2];
            byte2 = byte2 << 8;
            byte3 = r_message.data[3];
            manifold_air_pressure = byte2 + byte3;
            //Serial.print("manifold air pressure: ");
            //Serial.println(manifold_air_pressure);
            if(addr == 51){
              return manifold_air_pressure;
            }
            
            // manifold air temperature
            byte4 = r_message.data[4];
            byte4 = byte4 << 8;
            byte5 = r_message.data[5];
            manifold_air_temp = byte4 + byte5;
            //Serial.print("manifold air temperature: ");
            //Serial.println(manifold_air_temp);
            if(addr == 52){
              return manifold_air_temp;
            }
  
            // throttle position
            byte6 = r_message.data[6];
            byte6 = byte6 << 8;
            byte7 = r_message.data[7];
            throttle_posn = byte6 + byte7;
            if(addr == 31){
              return throttle_posn;
            }

            //Serial.print("throttle position: ");
            //Serial.println(throttle_posn);

          case 0x649: // engine oil temp
             // engine oil temp
            byte1 = r_message.data[1];
            engine_oil_temp = byte1;
            if(addr == 21){
              return engine_oil_temp;
            }
             //Serial.print("engine oil temperature: ");
             //Serial.println(engine_oil_temp);
            // coolant temp: 0th and 1st bytes

            byte0 = r_message.data[0];
            // byte0 = byte0 << 8; //shift by 8 bits
            // byte1 = r_message.data[1];
            coolant_temp = byte0;
            // Serial.print("Coolant Temp: ");
            // Serial.println(coolant_temp);
            if(addr == 53){
              return coolant_temp;
            }

          case 0x644: // oil pressure
            // oil pressure: 6th and 7th bytes
            byte6 = r_message.data[6];
            byte6 = byte6 << 8; //shift by 8 bits
            byte7 = r_message.data[7];
            oil_pressure = byte6 + byte7;
            // Serial.print("Oil Pressure: ");
            // Serial.println(oil_pressure);
            if(addr == 20){
              return oil_pressure;
            }

          case 0x64E: // Neutral Gear Switch
            // Neutral Gear: 31st bit (on the first bit)
            byte4 = r_message.data[4];
            byte4 = byte4 & 128; // deci number for 10000000
            neut_gear = byte4;
            if(addr == 30){
              return neut_gear;
            }
            // Serial.print("Neutral Gear: ");
           // Serial.println(neut_gear);
          case 0x64D: 
            byte4 = r_message.data[4];
            nibble13 = byte4 & 0b00001111;
            gear = nibble13;
            if(addr == 32){
              return gear;
            }
        }
      }
    }
    else
    {
      //Serial.println("No signal...");
	  return;
    }
  }
}
